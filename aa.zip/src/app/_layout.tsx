import { Stack } from "expo-router";
export default function RootLayout() {
  return <Stack screenOptions={{ headerStyle: { backgroundColor: "#111827" }, headerTintColor: "#fff", contentStyle: { backgroundColor: "#0b1020" } }} />;
}
